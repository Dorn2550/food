function Footer(){
    return(
        <>
        <div className="flex items-center justify-center bg-white h-10 text-center mt-5">
        <p className="text-gray-400 text-sm">ITFeature</p>
        </div>
      
        </>
    )
}
export default Footer;